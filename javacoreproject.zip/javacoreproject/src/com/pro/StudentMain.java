package com.pro;


public class StudentMain {

	public static void main(String[] args) {
		StudentManagement stu1=new StudentManagement();
		 stu1.enroll();
		 stu1.PayTution();
		 System.out.println(stu1.toString());
		 

		 StudentManagement stu2 = new StudentManagement();
		 stu2.enroll();
		 stu2.PayTution();
		 System.out.println(stu2.toString());
		 
		 StudentManagement stu3 = new StudentManagement();
		 stu3.enroll();
		 stu3.PayTution();
		 System.out.println(stu3.toString());
		 
		 // Ask how many new users we want to add
		 
		 // Create n number of new students

	}

}
