package com.pro;

import java.util.Scanner;


	public class StudentManagement {
		private String firstname;
		private String lastname;
		private int gradeyear;
		private String studentID;
		private String courses = "";
		private int tutionBalance = 0;
		private static int costofcourse = 2000;
		private static int id = 1000;
	 
		//constructor:prompt user to enter student's name and year

		public StudentManagement() {
			Scanner sc=new Scanner(System.in);
			System.out.println("*****************'WELCOME TO STUDENT MANAGEMENT SYSTEM'*****************");
			System.out.println("Enter student first name: ");
			this.firstname = sc.nextLine();
			
			System.out.println("Enter student last name: ");
			this.lastname = sc.nextLine();
			
			
			System.out.println("1 - fresher\n2 - junior\n3 - senior\nEnter student class level: ");
			this.gradeyear = sc.nextInt();
			
			
			setstudentID();
			
			System.out.println(firstname + " " + lastname + " " + gradeyear + " " + studentID);
			
			
		} 
		
	   //Genarate an ID
		
		private void setstudentID() {
			
		 //Grade level id + ID
			id++;
		    this.studentID = gradeyear + "" + id;
		}
	         
		//Enroll is course
		
	     public void enroll() {
	    	 do {
	    	 System.out.println("Enter course to enroll (Q to Quit): ");
	    	 Scanner sc = new Scanner(System.in);
	    	 String course = sc.nextLine();
	    	 if(!course.equals( "Q")) {
	    		 courses = courses + "\n" + course;
	    		 tutionBalance = tutionBalance + costofcourse;
	    		 
	    	 }
	    	 else {
	    		 System.out.println("BREAK!");
	    		 break;
	    		 }
	    	 } while (1 != 0);
	    	 
	    	 System.out.println("Enrolled in: " + courses);
	    	 System.out.println("Tution fees: " +  tutionBalance);
	    	 
	    	

	     }
	     public void ViewBalance() {
	    	 System.out.println("Your Balance is: $" + tutionBalance);
	     }
    public void PayTution() {
    	ViewBalance();
    	System.out.println("enter the payment");
    	Scanner sc= new Scanner(System.in);
    	int payment= sc.nextInt();
    	tutionBalance = tutionBalance - payment;
    	System.out.println("Thank you for payment of $ " + payment);
    	ViewBalance();
    }
    public String toString() {
		return "Name:" + firstname + " " + lastname +
				"\n StudentId:" +studentID+
				"\nCorses Enrolled:" + courses +
				"\nBalance : $" + tutionBalance;
    	
    }
	}

